# -*- coding: utf-8 -*-
from __future__ import print_function

import hashlib
import threading
import os
import re
import socket
import ssl
import subprocess
import time
import zlib
from html import unescape
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox

try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    VirtualKeyBoard = None

try:
    from Screens.ChoiceBox import ChoiceBox
except Exception:
    ChoiceBox = None

try:
    from Screens.LocationBox import MovieLocationBox
except Exception:
    MovieLocationBox = None

from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
try:
    from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
except Exception:
    MultiContentEntryText = None
    MultiContentEntryPixmapAlphaTest = None
try:
    from Components.Pixmap import Pixmap
except Exception:
    Pixmap = None
try:
    from Components.ProgressBar import ProgressBar
except Exception:
    ProgressBar = None
from Components.config import (
    config,
    ConfigSubsection,
    ConfigSelection,
    ConfigText,
    getConfigListEntry,
)
from Components.ConfigList import ConfigListScreen
from enigma import eServiceReference

try:
    from enigma import eDVBDB, iPlayableService, iServiceInformation, eTimer, gFont, loadJPG, loadPNG, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_VALIGN_CENTER, RT_WRAP, getDesktop
except Exception:
    eDVBDB = None
    iPlayableService = None
    iServiceInformation = None
    eTimer = None
    gFont = None
    eListboxPythonMultiContent = None
    getDesktop = None
    RT_HALIGN_LEFT = 0
    RT_VALIGN_CENTER = 0
    RT_WRAP = 0

try:
    from Components.ServiceEventTracker import ServiceEventTracker
except Exception:
    ServiceEventTracker = None

# For file browser
try:
    from Components.FileList import FileList
    from Components.Sources.StaticText import StaticText
except Exception:
    FileList = None
    StaticText = None

PLUGIN_NAME = "MyHits"
PLUGIN_VERSION = "1.0.0"
APP_BROWSER_TITLE = "%s Browser" % PLUGIN_NAME
APP_PLAYER_TITLE = "%s Player" % PLUGIN_NAME
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/91.0.4472.124 Safari/537.36"
)
SOCKET_TIMEOUT = 20
BOUQUETS_TV_FILE = "/etc/enigma2/bouquets.tv"
ENIGMA2_DIR = "/etc/enigma2"
CACHE_DIR = "/tmp/myhits_cache"
CACHE_TTL = 12 * 60 * 60
IMG_DIR = os.path.join(os.path.dirname(__file__), "img")


# =========================================================================
# DYNAMIC RESOLUTION SCALING ENGINE (Supports HD, FHD, 2K/WQHD, 4K)
# =========================================================================
try:
    if getDesktop is not None:
        screenWidth = getDesktop(0).size().width()
    else:
        screenWidth = 1280
except Exception:
    screenWidth = 1280

if screenWidth >= 2560:
    SKIN_SCALE = 2.0  # WQHD / 4K
    PLUGIN_LOGO = os.path.join(IMG_DIR, "myhits_wqhd_logo.png")
elif screenWidth >= 1920:
    SKIN_SCALE = 1.5  # FHD
    PLUGIN_LOGO = os.path.join(IMG_DIR, "myhits_fhd_logo.png")
else:
    SKIN_SCALE = 1.0  # HD
    PLUGIN_LOGO = os.path.join(IMG_DIR, "myhits_fhd_logo.png") # Fallback

def scale_int(val):
    return int(round(float(val) * SKIN_SCALE))

def scale_skin(skin_xml):
    if not skin_xml:
        return skin_xml
        
    res = skin_xml.replace("{LOGO_PATH}", PLUGIN_LOGO)
    
    if SKIN_SCALE == 1.0:
        return res
    
    def scale_coords(match):
        attr = match.group(1)
        coords = match.group(2).split(',')
        scaled = []
        for x in coords:
            x = x.strip()
            if x.isdigit():
                scaled.append(str(int(round(float(x) * SKIN_SCALE))))
            elif x.lstrip('-').isdigit():
                scaled.append(str(int(round(float(x) * SKIN_SCALE))))
            else:
                scaled.append(x)
        return '%s="%s"' % (attr, ",".join(scaled))

    def scale_font(match):
        font_name = match.group(1)
        font_size = int(round(float(match.group(2)) * SKIN_SCALE))
        return 'font="%s;%d"' % (font_name, font_size)

    res = re.sub(r'(size|position)="([^"]+)"', scale_coords, res)
    res = re.sub(r'font="([^;]+);([0-9]+)"', scale_font, res)
    res = re.sub(r'(itemHeight)="([0-9]+)"', lambda m: '%s="%d"' % (m.group(1), int(round(float(m.group(2)) * SKIN_SCALE))), res)
    res = re.sub(r'(cornerRadius)="([0-9]+)"', lambda m: '%s="%d"' % (m.group(1), int(round(float(m.group(2)) * SKIN_SCALE))), res)
    return res
# =========================================================================


def ensure_storage_dirs():
    root = config.plugins.myhits.storage_path.value or "/tmp/MyHits"
    paths = [root, os.path.join(root, "singers"), os.path.join(root, "cover_art")]
    for p in paths:
        try:
            if not os.path.isdir(p):
                os.makedirs(p)
        except Exception:
            pass
    return root


def get_singers_dir():
    return os.path.join(ensure_storage_dirs(), "singers")


def get_cover_art_dir():
    return os.path.join(ensure_storage_dirs(), "cover_art")

if not hasattr(config.plugins, "myhits"):
    config.plugins.myhits = ConfigSubsection()

config.plugins.myhits.player = ConfigSelection(
    default="5002",
    choices=[("5002", "5002 (FFmpeg / ServiceApp)")],
)
config.plugins.myhits.cache_ttl = ConfigSelection(
    default="43200",
    choices=[
        ("3600", "1 hour"),
        ("21600", "6 hours"),
        ("43200", "12 hours"),
        ("86400", "24 hours"),
    ],
)
config.plugins.myhits.storage_path = ConfigText(default="/tmp/MyHits", fixed_size=False)
config.plugins.myhits.search_history = ConfigSelection(default="", choices=[("", "")])

_PAGE_CACHE = {}
_PARSE_CACHE = {
    "singers": {},
    "albums": {},
    "album_image": {},
    "songs": {},
    "song_stream": {},
    "singer_image": {},
    "image_file": {},
}


def ensure_cache_dir():
    if not os.path.isdir(CACHE_DIR):
        try:
            os.makedirs(CACHE_DIR)
        except Exception:
            pass


def get_cache_ttl():
    try:
        return int(config.plugins.myhits.cache_ttl.value)
    except Exception:
        return CACHE_TTL


def clean_text(text):
    return " ".join((text or "").replace("\xa0", " ").split()).strip()


def strip_tags(html):
    text = re.sub(r"<[^>]+>", " ", html or "")
    return clean_text(unescape(text))


def safe_bouquet_key(text):
    text = clean_text(text).lower()
    text = re.sub(r"\s+", "_", text)
    text = re.sub(r"[^0-9A-Za-z_\-\u0600-\u06FF]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("._")
    return text or "myhits"


def fetch_url(url, force=False):
    now = int(time.time())
    if not force:
        cached = _PAGE_CACHE.get(url)
        ttl = get_cache_ttl()
        if cached and now - cached[0] < ttl:
            return cached[1]

    ensure_cache_dir()
    cache_key = hashlib.md5(url.encode("utf-8")).hexdigest() + ".cache"
    cache_path = os.path.join(CACHE_DIR, cache_key)
    if not force and os.path.exists(cache_path):
        try:
            mtime = int(os.path.getmtime(cache_path))
            if now - mtime < ttl:
                with open(cache_path, "r", encoding="utf-8") as handle:
                    data = handle.read()
                _PAGE_CACHE[url] = (now, data)
                return data
        except Exception:
            pass

    req = Request(url, headers={"User-Agent": USER_AGENT})
    context = ssl.create_default_context()
    with urlopen(req, timeout=SOCKET_TIMEOUT, context=context) as response:
        data = response.read()
    try:
        html = data.decode("utf-8", "ignore")
    except Exception:
        html = data.decode("latin-1", "ignore")

    _PAGE_CACHE[url] = (now, html)
    try:
        with open(cache_path, "w", encoding="utf-8") as handle:
            handle.write(html)
    except Exception:
        pass
    return html


def clear_cache():
    _PAGE_CACHE.clear()
    for bucket in _PARSE_CACHE.values():
        bucket.clear()
    if os.path.isdir(CACHE_DIR):
        for name in os.listdir(CACHE_DIR):
            path = os.path.join(CACHE_DIR, name)
            try:
                os.remove(path)
            except Exception:
                pass


def find_first(pattern, text, flags=0):
    match = re.search(pattern, text or "", flags)
    return match.group(1) if match else ""


def format_album_name(name):
    match = re.search(r"(\d{4})$", name)
    if match:
        year = match.group(1)
        name_without_year = name[:-len(year)].rstrip()
        return "%s (%s)" % (name_without_year, year)
    return name


def build_stream_reference(title, stream_url):
    ref = eServiceReference(5002, 0, stream_url)
    ref.setName(title or PLUGIN_NAME)
    return ref


def get_singer_bouquet_filename(singer_name):
    return "userbouquet.%s.tv" % safe_bouquet_key(singer_name)


def _ensure_bouquet_header(path, bouquet_name):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("#NAME %s\n" % bouquet_name)


def _ensure_bouquet_registered(filename):
    ref_line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % filename
    if not os.path.exists(BOUQUETS_TV_FILE):
        with open(BOUQUETS_TV_FILE, "w", encoding="utf-8") as handle:
            handle.write("#NAME User - bouquets (TV)\n")
            handle.write(ref_line + "\n")
        return
    with open(BOUQUETS_TV_FILE, "r", encoding="utf-8") as handle:
        content = handle.read()
    if ref_line not in content:
        if not content.endswith("\n"):
            content += "\n"
        content += ref_line + "\n"
        with open(BOUQUETS_TV_FILE, "w", encoding="utf-8") as handle:
            handle.write(content)


def _build_bouquet_service_line(title, stream_url):
    title = clean_text(title or PLUGIN_NAME)
    encoded_url = quote(stream_url, safe="")
    crc = zlib.crc32((title + "|" + stream_url).encode("utf-8")) & 0xFFFFFFFF
    sid = (crc & 0xFFFF) or 1
    tsid = ((crc >> 16) & 0xFFFF) or 1
    onid = ((crc >> 8) & 0xFFFF) or 1
    namespace = 0
    return "#SERVICE 5002:0:1:%X:%X:%X:%X:0:0:0:%s:%s" % (sid, tsid, onid, namespace, encoded_url, title)


def _reload_bouquets():
    if eDVBDB is not None:
        try:
            eDVBDB.getInstance().reloadBouquets()
        except Exception:
            pass


def add_service_to_singer_bouquet(singer_name, title, stream_url):
    if not stream_url:
        return False, "No stream URL found."
    bouquet_file = get_singer_bouquet_filename(singer_name)
    bouquet_name = clean_text(singer_name or PLUGIN_NAME)
    bouquet_path = os.path.join(ENIGMA2_DIR, bouquet_file)
    try:
        _ensure_bouquet_header(bouquet_path, bouquet_name)
        _ensure_bouquet_registered(bouquet_file)
        service_line = _build_bouquet_service_line(title, stream_url)
        desc_line = "#DESCRIPTION %s" % clean_text(title)
        existing = ""
        if os.path.exists(bouquet_path):
            with open(bouquet_path, "r", encoding="utf-8") as handle:
                existing = handle.read()
        if stream_url in existing or desc_line in existing:
            return True, "Already exists in bouquet %s." % bouquet_name
        with open(bouquet_path, "a", encoding="utf-8") as handle:
            if existing and not existing.endswith("\n"):
                handle.write("\n")
            handle.write(service_line + "\n")
            handle.write(desc_line + "\n")
        _reload_bouquets()
        return True, "Added to bouquet %s." % bouquet_name
    except Exception as err:
        return False, "Failed to update bouquet: %s" % err


def getAudioBitrate(url):
    """Get audio bitrate from stream URL using ffprobe (returns kbps or None)"""
    try:
        cmd = [
            'ffprobe',
            '-v', 'error',
            '-select_streams', 'a:0',
            '-show_entries', 'stream=bit_rate',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            url
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
        if result.returncode == 0:
            bitrate_bps = result.stdout.decode('utf-8').strip()
            if bitrate_bps and bitrate_bps != 'N/A':
                return int(bitrate_bps) // 1000
        cmd2 = [
            'ffprobe',
            '-v', 'error',
            '-show_entries', 'format=bit_rate',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            url
        ]
        result2 = subprocess.run(cmd2, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
        if result2.returncode == 0:
            bitrate_bps = result2.stdout.decode('utf-8').strip()
            if bitrate_bps and bitrate_bps != 'N/A':
                return int(bitrate_bps) // 1000
    except Exception:
        pass
    return None




def _hash_name(url):
    return hashlib.md5((url or "").encode("utf-8")).hexdigest()


def _guess_image_ext(url, data=None):
    lower = (url or "").lower()
    for ext in [".jpg", ".jpeg", ".png", ".webp"]:
        if ext in lower:
            return ext
    if data:
        if data.startswith(b"\x89PNG"):
            return ".png"
        if data.startswith(b"\xff\xd8"):
            return ".jpg"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return ".webp"
    return ".img"


def download_binary(url):
    req = Request(url, headers={"User-Agent": USER_AGENT})
    context = ssl.create_default_context()
    with urlopen(req, timeout=SOCKET_TIMEOUT, context=context) as response:
        return response.read()


def _download_and_prepare_image(image_url, target_dir):
    if not image_url:
        return ""
    ensure_storage_dirs()
    key = _hash_name(image_url)
    for ext in (".jpg", ".jpeg", ".png"):
        p = os.path.join(target_dir, key + ext)
        if os.path.exists(p):
            return p
    try:
        data = download_binary(image_url)
        ext = _guess_image_ext(image_url, data)
        raw_path = os.path.join(target_dir, key + ext)
        if not os.path.exists(raw_path):
            with open(raw_path, "wb") as f:
                f.write(data)
        final_path = raw_path
        if ext == ".webp" or ext == ".img":
            jpg_path = os.path.join(target_dir, key + ".jpg")
            if not os.path.exists(jpg_path):
                try:
                    subprocess.run(["ffmpeg", "-y", "-i", raw_path, jpg_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
                except Exception:
                    pass
            if os.path.exists(jpg_path):
                final_path = jpg_path
        return final_path if os.path.exists(final_path) else ""
    except Exception:
        return ""


def get_local_singer_image_file(image_url):
    cache = _PARSE_CACHE.get("image_file", {})
    cache_key = "singer:" + (image_url or "")
    if image_url in (None, ""):
        return ""
    if cache_key in cache and os.path.exists(cache[cache_key]):
        return cache[cache_key]
    path = _download_and_prepare_image(image_url, get_singers_dir())
    if path:
        cache[cache_key] = path
        _PARSE_CACHE["image_file"] = cache
    return path


def get_local_cover_art_file(image_url):
    cache = _PARSE_CACHE.get("image_file", {})
    cache_key = "cover:" + (image_url or "")
    if image_url in (None, ""):
        return ""
    if cache_key in cache and os.path.exists(cache[cache_key]):
        return cache[cache_key]
    path = _download_and_prepare_image(image_url, get_cover_art_dir())
    if path:
        cache[cache_key] = path
        _PARSE_CACHE["image_file"] = cache
    return path


def set_pixmap_from_file(pixmap_widget, path):
    if pixmap_widget is None or not path or not os.path.exists(path):
        return False
    try:
        try:
            pixmap_widget.instance.setScale(1)
        except Exception:
            pass
        lower = path.lower()
        ptr = None
        if lower.endswith(".png"):
            ptr = loadPNG(path)
        else:
            ptr = loadJPG(path)
        if ptr is not None:
            pixmap_widget.instance.setPixmap(ptr)
            pixmap_widget.show()
            return True
    except Exception:
        pass
    return False


def clear_pixmap(pixmap_widget):
    try:
        if pixmap_widget is not None:
            pixmap_widget.hide()
    except Exception:
        pass

class AlbumatySite(object):
    name = "Albumaty"
    url = "https://www.albumaty.com/cat/1.html"

    def get_singers(self):
        if self.url in _PARSE_CACHE["singers"]:
            return list(_PARSE_CACHE["singers"][self.url])
        html = fetch_url(self.url)
        items = []
        pattern = re.compile(r'<div[^>]+class="[^"]*country-singers[^"]*"[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', re.S | re.I)
        seen = set()
        for href, title_html in pattern.findall(html):
            name = strip_tags(title_html)
            name = re.sub(r"^اغاني\s*", "", name).strip()
            url = urljoin(self.url, href)
            key = (name, url)
            if name and key not in seen:
                seen.add(key)
                items.append({"name": name, "url": url})
        _PARSE_CACHE["singers"][self.url] = list(items)
        return items

    def get_albums(self, singer_url):
        if singer_url in _PARSE_CACHE["albums"]:
            return list(_PARSE_CACHE["albums"][singer_url])
        html = fetch_url(singer_url)
        
        block = find_first(r'<div[^>]+class="[^"]*singer-albums[^"]*"[^>]*>(.*?)</div>\s*</div>', html, re.S | re.I)
        if not block:
            block = html
            
        items = []
        
        # Add the 'Singel' category as the first item
        items.append({"name": "Singel", "url": singer_url + "#singles"})
        
        pattern = re.compile(r'<li[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', re.S | re.I)
        for href, title_html in pattern.findall(block):
            name = format_album_name(strip_tags(title_html))
            url = urljoin(singer_url, href)
            if name and "/song/" not in href:
                items.append({"name": name, "url": url})
                
        _PARSE_CACHE["albums"][singer_url] = list(items)
        return items

    def get_last_albums(self, url):
        if url in _PARSE_CACHE["albums"]:
            return list(_PARSE_CACHE["albums"][url])
        html = fetch_url(url)
        items = []
        pattern = re.compile(r'<div[^>]+class="[^"]*country-singers[^"]*"[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', re.S | re.I)
        seen = set()
        for href, title_html in pattern.findall(html):
            name = format_album_name(strip_tags(title_html))
            full_url = urljoin(url, href)
            if name and full_url not in seen and "cat" not in href and "singers" not in href and href != "#":
                seen.add(full_url)
                items.append({"name": name, "url": full_url})
        _PARSE_CACHE["albums"][url] = list(items)
        return items

    def get_last_songs(self, url):
        if url in _PARSE_CACHE["songs"]:
            return list(_PARSE_CACHE["songs"][url])
        html = fetch_url(url)
        items = []
        pattern = re.compile(
            r'<li[^>]+class="[^"]*col-md-6[^"]*"[^>]*>.*?<div[^>]+class="[^"]*pull-right[^"]*"[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>.*?<div[^>]+class="[^"]*pull-left[^"]*"[^>]*>.*?<a[^>]+href="[^"]+"[^>]*>(.*?)</a>',
            re.S | re.I
        )
        seen = set()
        for song_href, song_title, singer_title in pattern.findall(html):
            song_name = strip_tags(song_title)
            singer_name = strip_tags(singer_title)
            full_name = "%s - %s" % (song_name, singer_name)
            full_url = urljoin(url, song_href)
            if song_name and full_url not in seen and song_href != "#":
                seen.add(full_url)
                items.append({"name": full_name, "url": full_url})
        _PARSE_CACHE["songs"][url] = list(items)
        return items

    def get_album_image(self, album_url):
        clean_url = album_url.split('#')[0]
        if album_url in _PARSE_CACHE["album_image"]:
            return _PARSE_CACHE["album_image"][album_url]
        html = fetch_url(clean_url)
        image = find_first(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', html, re.I)
        image = urljoin(clean_url, image) if image else ""
        _PARSE_CACHE["album_image"][album_url] = image
        return image

    def get_songs(self, album_url):
        clean_url = album_url.split('#')[0]
        if album_url in _PARSE_CACHE["songs"]:
            return list(_PARSE_CACHE["songs"][album_url])
        
        html = fetch_url(clean_url)
        
        if "#singles" in album_url:
            block = find_first(r'<div[^>]+class="[^"]*singer-songs[^"]*"[^>]*>(.*?)</ul>', html, re.S | re.I)
        else:
            block = find_first(r'<div[^>]+class="[^"]*single-album[^"]*"[^>]*>.*?<h2>.*?اغاني البوم.*?</h2>(.*?)</ul>', html, re.S | re.I)
            
        if not block:
            block = html
            
        items = []
        pattern = re.compile(r'<li[^>]*>.*?<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', re.S | re.I)
        for href, title_html in pattern.findall(block):
            name = strip_tags(title_html)
            url = urljoin(clean_url, href)
            if name and "/song/" in href:
                items.append({"name": name, "url": url})
                
        _PARSE_CACHE["songs"][album_url] = list(items)
        return items

    def get_song_stream_url(self, song_url):
        if song_url in _PARSE_CACHE["song_stream"]:
            return _PARSE_CACHE["song_stream"][song_url]
        html = fetch_url(song_url)
        stream = find_first(r'<audio[^>]+src="([^"]+)"', html, re.S | re.I)
        stream = urljoin(song_url, stream) if stream else ""
        _PARSE_CACHE["song_stream"][song_url] = stream
        return stream

    def get_singer_image(self, singer_url):
        cache = _PARSE_CACHE["singer_image"]
        if singer_url in cache:
            return cache[singer_url]
        html = fetch_url(singer_url)
        image = find_first(r'<div[^>]+class="[^"]*artist-card[^"]*"[^>]*>.*?<img[^>]+src="([^"]+)"', html, re.S | re.I)
        if not image:
            image = find_first(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', html, re.I)
        if not image:
            image = find_first(r'<meta[^>]+name="twitter:image"[^>]+content="([^"]+)"', html, re.I)
        image = urljoin(singer_url, image) if image else ""
        cache[singer_url] = image
        return image



SITE_PROVIDERS = [AlbumatySite()]


class MyhitsPlayerScreen(Screen):
    skin = """
    <screen name="MyhitsPlayerScreen" position="center,450" size="1180,220" title="MyHits Player">
        <widget name="title_label" position="20,10" size="1140,36" font="Regular;30" halign="left" valign="center" />
        <widget name="artist_label" position="20,48" size="1140,28" font="Regular;24" halign="left" valign="center" />
        <widget name="status" position="20,78" size="1140,24" font="Regular;22" halign="left" valign="center" />
        <widget name="progress" position="21,109" size="1138,14" zPosition="5" backgroundColor="#00000000" foregroundColor="#0000ff00" />
        <widget name="position_label" position="20,130" size="250,26" font="Regular;22" halign="left" valign="center" />
        <widget name="duration_label" position="300,130" size="250,26" font="Regular;22" halign="left" valign="center" />
        <widget name="bitrate_label" position="580,130" size="300,26" font="Regular;22" halign="left" valign="center" />
        <widget name="key_red" position="20,164" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="20,200" size="220,8" backgroundColor="#b71c1c" />
        <widget name="key_green" position="250,164" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="250,200" size="220,8" backgroundColor="#1b5e20" />
        <widget name="key_yellow" position="480,164" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="480,200" size="220,8" backgroundColor="#f9a825" />
        <widget name="key_blue" position="710,164" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="710,200" size="220,8" backgroundColor="#0d47a1" />
        <eLabel name="" position="20,108" size="1140,16" backgroundColor="#00a5a5a5" zPosition="2" />
</screen>
    """

    def __init__(self, session, provider, singer, album, queue, start_index=0):
        if hasattr(self.__class__, 'skin'):
            self.skin = scale_skin(self.__class__.skin)
        Screen.__init__(self, session)
        self.provider = provider
        self.singer = singer
        self.album = album
        self.queue = queue or []
        self.current_index = max(0, min(start_index, len(self.queue) - 1)) if self.queue else 0
        self.old_service = None
        self.user_stopped = False
        self.timer = None
        self._bitrate_thread = None
        self._bitrate_value = None
        self._bitrate_song_url = ""
        self["title_label"] = Label("")
        self["artist_label"] = Label("")
        self["status"] = Label("Starting playback...")
        self["position_label"] = Label("Position: 00:00")
        self["duration_label"] = Label("Duration: --:--")
        self["bitrate_label"] = Label("Bitrate: -- kb/s")
        self["key_red"] = Label("Stop")
        self["key_green"] = Label("Next")
        self["key_yellow"] = Label("Previous")
        self["key_blue"] = Label("Queue")
        if ProgressBar is not None:
            self["progress"] = ProgressBar()
            self["progress"].setRange((0, 1000))
            self["progress"].setValue(0)
        else:
            self["progress"] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "MediaPlayerActions", "DirectionActions"],
            {
                "cancel": self.keyStop,
                "red": self.keyStop,
                "stop": self.keyStop,
                "green": self.keyNext,
                "yellow": self.keyPrev,
                "blue": self.keyQueue,
                "right": self.keyNext,
                "left": self.keyPrev,
                "ok": self.keyInfo,
            },
            -1,
        )
        self.onFirstExecBegin.append(self.startPlayback)
        self.onClose.append(self._onClose)
        if ServiceEventTracker is not None and iPlayableService is not None:
            self.__event_tracker = ServiceEventTracker(
                screen=self,
                eventmap={
                    iPlayableService.evStart: self.evStart,
                    iPlayableService.evEOF: self.evEOF,
                    iPlayableService.evStopped: self.evStopped,
                },
            )
        if eTimer is not None:
            self.timer = eTimer()
            try:
                self.timer.timeout.connect(self.updateProgress)
            except Exception:
                self.timer.callback.append(self.updateProgress)

    def startPlayback(self):
        if not self.queue:
            self.session.open(MessageBox, "Queue is empty.", MessageBox.TYPE_ERROR)
            self.close()
            return
        try:
            self.old_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            self.old_service = None
        self.playCurrentSong()

    def _current_song(self):
        if 0 <= self.current_index < len(self.queue):
            return self.queue[self.current_index]
        return None

    def _fmt_time(self, ms_value):
        if ms_value is None or ms_value < 0:
            return "--:--"
        seconds = int(ms_value / 90000) if ms_value > 10000 else int(ms_value)
        minutes = seconds // 60
        seconds = seconds % 60
        return "%02d:%02d" % (minutes, seconds)

    def playCurrentSong(self):
        song = self._current_song()
        if not song:
            self.session.open(MessageBox, "No song selected.", MessageBox.TYPE_ERROR)
            self.close()
            return
        try:
            stream_url = song.get("stream_url") or self.provider.get_song_stream_url(song.get("url", ""))
            song["stream_url"] = stream_url
            if not stream_url:
                self.session.open(MessageBox, "No playable audio stream found for this song.", MessageBox.TYPE_ERROR)
                return
            self["title_label"].setText(song.get("name", "Song"))
            self["artist_label"].setText("%s / %s" % (self.singer.get("name", ""), self.album.get("name", "")))
            self["status"].setText("Loading %d/%d" % (self.current_index + 1, len(self.queue)))
            self["position_label"].setText("Position: 00:00")
            self["duration_label"].setText("Duration: --:--")
            self["bitrate_label"].setText("Bitrate: probing...")
            self._bitrate_value = None
            self._bitrate_song_url = stream_url
            try:
                self._bitrate_thread = threading.Thread(target=self._probeBitrateWorker, args=(stream_url,), daemon=True)
                self._bitrate_thread.start()
            except Exception:
                self._bitrate_thread = None
            if ProgressBar is not None:
                self["progress"].setValue(0)
            ref = build_stream_reference(song.get("name", "Song"), stream_url)
            self.session.nav.playService(ref)
            if self.timer is not None:
                try:
                    self.timer.start(1000)
                except Exception:
                    self.timer.start(1000, False)
        except Exception as err:
            self.session.open(MessageBox, "Failed to play song:\n%s" % err, MessageBox.TYPE_ERROR)


    def _probeBitrateWorker(self, stream_url):
        try:
            self._bitrate_value = getAudioBitrate(stream_url)
        except Exception:
            self._bitrate_value = None

    def updateProgress(self):
        service = self.session.nav.getCurrentService()
        if not service:
            return
        pos_text = "--:--"
        len_text = "--:--"
        bitrate_text = "-- kb/s"
        pct = 0
        try:
            seek = service.seek()
        except Exception:
            seek = None
        if seek is not None:
            try:
                pos = seek.getPlayPosition()
                length = seek.getLength()
                pos_val = pos and len(pos) > 1 and pos[0] == 0 and pos[1] or -1
                len_val = length and len(length) > 1 and length[0] == 0 and length[1] or -1
                pos_text = self._fmt_time(pos_val)
                len_text = self._fmt_time(len_val)
                if pos_val >= 0 and len_val > 0:
                    pct = int((float(pos_val) / float(len_val)) * 1000.0)
            except Exception:
                pass
        try:
            if self._bitrate_value is None:
                bitrate_text = "probing..."
            elif self._bitrate_value and self._bitrate_value > 0:
                bitrate_text = "%d kb/s" % int(self._bitrate_value)
            else:
                bitrate_text = "-- kb/s"
        except Exception:
            pass
        self["position_label"].setText("Position: %s" % pos_text)
        self["duration_label"].setText("Duration: %s" % len_text)
        self["bitrate_label"].setText("Bitrate: %s" % bitrate_text)
        try:
            if ProgressBar is not None:
                self["progress"].setValue(max(0, min(1000, pct)))
        except Exception:
            pass

    def evStart(self):
        self["status"].setText("Playing %d/%d (FFmpeg)" % (self.current_index + 1, len(self.queue)))

    def evEOF(self):
        if self.current_index + 1 < len(self.queue):
            self.current_index += 1
            self.playCurrentSong()
        else:
            self["status"].setText("Finished")

    def evStopped(self):
        self["status"].setText("Stopped")

    def keyInfo(self):
        self["status"].setText("Player active - Stop returns to songs and restores live TV")

    def keyQueue(self):
        song = self._current_song()
        current = song.get("name", "Song") if song else "-"
        self["status"].setText("Queue %d/%d: %s" % (self.current_index + 1, len(self.queue), current))

    def keyNext(self):
        if self.current_index + 1 < len(self.queue):
            self.current_index += 1
            self.playCurrentSong()
        else:
            self["status"].setText("Last song in queue")

    def keyPrev(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.playCurrentSong()
        else:
            self["status"].setText("First song in queue")

    def _restoreOldService(self):
        if self.old_service is not None:
            try:
                self.session.nav.playService(self.old_service)
            except Exception:
                pass

    def keyStop(self):
        self.user_stopped = True
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self._restoreOldService()
        self.close()

    def _onClose(self):
        if self.timer is not None:
            try:
                self.timer.stop()
            except Exception:
                pass
        if not self.user_stopped:
            self._restoreOldService()


class MyhitsBrowserBase(Screen):
    skin = """
    <screen name="MyhitsBrowserBase" position="center,center" size="1100,630" title="MyHits Browser">
        <widget name="title" position="20,15" size="1060,40" font="Regular;30" />
        <widget name="status" position="20,60" size="1060,32" font="Regular;24" />
        <widget name="list" position="20,100" size="1060,430" scrollbarMode="showOnDemand" itemHeight="40" font="Regular;30" valign="center" />
        <widget name="key_red" position="20,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="20,596" size="220,8" backgroundColor="#b71c1c" />
        <widget name="key_green" position="250,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="250,596" size="220,8" backgroundColor="#1b5e20" />
        <widget name="key_yellow" position="480,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="480,596" size="220,8" backgroundColor="#f9a825" />
        <widget name="key_blue" position="710,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="710,596" size="220,8" backgroundColor="#0d47a1" />
        <widget name="key_menu" position="940,560" size="140,32" font="Regular;24" halign="center" valign="center" />
    </screen>
    """

    def __init__(self, session, title, items=None, status=""):
        if hasattr(self.__class__, 'skin'):
            self.skin = scale_skin(self.__class__.skin)
        Screen.__init__(self, session)
        full_title = "%s v%s - %s" % (APP_BROWSER_TITLE, PLUGIN_VERSION, title)
        self["title"] = Label(full_title)
        try:
            self.setTitle(full_title)
        except Exception:
            pass
        self["status"] = Label(status)
        self["key_red"] = Label("Back")
        self["key_green"] = Label("Open")
        self["key_yellow"] = Label("Search")
        self["key_blue"] = Label("")
        self["key_menu"] = Label("")
        self["list"] = MenuList([])
        try:
            if gFont is not None:
                self["list"].l.setFont(0, gFont("Regular", scale_int(30)))
                self["list"].l.setItemHeight(scale_int(40))
        except Exception:
            pass
        self.all_items = items or []
        self.filtered_items = list(self.all_items)
        self.search_term = ""
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "MenuActions"],
            {
                "ok": self.keyOK,
                "green": self.keyOK,
                "cancel": self.close,
                "red": self.close,
                "yellow": self.keySearch,
                "blue": self.keyBlue,
                "menu": self.keyMenu,
            },
            -1,
        )
        self.updateList()

    def enableMenu(self, enabled, label="Menu"):
        self["key_menu"].setText(label if enabled else "")

    def setItems(self, items):
        self.all_items = items or []
        self.applyFilter(self.search_term)

    def updateList(self):
        self["list"].setList([item["name"] for item in self.filtered_items])
        self["status"].setText("%d item(s)" % len(self.filtered_items))

    def applyFilter(self, term):
        self.search_term = clean_text(term).lower()
        if self.search_term:
            self.filtered_items = [item for item in self.all_items if self.search_term in item.get("name", "").lower()]
        else:
            self.filtered_items = list(self.all_items)
        self.updateList()

    def getCurrentItem(self):
        index = self["list"].getSelectionIndex()
        if 0 <= index < len(self.filtered_items):
            return self.filtered_items[index]
        return None

    def keySearch(self):
        if VirtualKeyBoard is None:
            self.session.open(MessageBox, "Virtual keyboard is not available.", MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title="Search", text=self.search_term)

    def searchCallback(self, text=None):
        if text is not None:
            self.applyFilter(text)

    def keyBlue(self):
        pass

    def keyMenu(self):
        pass

    def keyOK(self):
        item = self.getCurrentItem()
        if item:
            self.openItem(item)

    def openItem(self, item):
        pass


class MyhitsMainScreen(MyhitsBrowserBase):
    def __init__(self, session):
        items = [{"name": provider.name, "provider": provider} for provider in SITE_PROVIDERS]
        MyhitsBrowserBase.__init__(self, session, "Main", items, "Choose a music provider")
        self["key_blue"].setText("Settings")

    def keyBlue(self):
        self.session.open(MyhitsSettingsScreen)

    def openItem(self, item):
        provider = item.get("provider")
        if provider:
            screen = PROVIDER_SINGER_SCREENS.get(provider.name, MyhitsSingerScreen)
            self.session.open(screen, provider)


class AlbumatyMenuScreen(MyhitsBrowserBase):
    def __init__(self, session, provider):
        self.provider = provider
        items = [
            {"name": "Singers", "type": "singers"},
            {"name": "last albums", "type": "last_albums", "url": "https://www.albumaty.com/lastalbums.html"},
            {"name": "last songs", "type": "last_songs", "url": "https://www.albumaty.com/nowlastsongsnow.html"}
        ]
        MyhitsBrowserBase.__init__(self, session, "%s Options" % provider.name, items, "Choose an category selection")

    def openItem(self, item):
        if item["type"] == "singers":
            self.session.open(AlbumatySingerScreen, self.provider)
        elif item["type"] == "last_albums":
            self.session.open(AlbumatyLastAlbumsScreen, self.provider, item["url"])
        elif item["type"] == "last_songs":
            self.session.open(AlbumatyLastSongsScreen, self.provider, item["url"])


class AlbumatyLastAlbumsScreen(MyhitsBrowserBase):
    def __init__(self, session, provider, url):
        self.provider = provider
        self.url = url
        MyhitsBrowserBase.__init__(self, session, "Last Albums", [], "Loading last albums...")
        self.loadData()

    def loadData(self):
        try:
            albums = self.provider.get_last_albums(self.url)
            self.setItems(albums)
            self["status"].setText("%d album(s)" % len(albums))
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading last albums.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to load last albums:\n%s" % err, MessageBox.TYPE_ERROR)

    def openItem(self, item):
        dummy_singer = {"name": "Various Singers", "url": ""}
        self.session.open(AlbumatySongScreen, self.provider, dummy_singer, item)


class AlbumatyLastSongsScreen(MyhitsBrowserBase):
    def __init__(self, session, provider, url):
        self.provider = provider
        self.url = url
        MyhitsBrowserBase.__init__(self, session, "Last Songs", [], "Loading last songs...")
        self["key_green"].setText("Play")
        self.loadData()

    def loadData(self):
        try:
            songs = self.provider.get_last_songs(self.url)
            self.setItems(songs)
            self["status"].setText("%d song(s)" % len(songs))
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading last songs.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to load last songs:\n%s" % err, MessageBox.TYPE_ERROR)

    def openItem(self, item):
        try:
            current = self.getCurrentItem()
            index = self.filtered_items.index(current) if current in self.filtered_items else 0
            queue = []
            for song in self.filtered_items:
                queue.append({"name": song.get("name", "Song"), "url": song.get("url", "")})
            dummy_singer = {"name": "Various Singers", "url": ""}
            dummy_album = {"name": "Last Songs", "url": ""}
            self.session.open(MyhitsPlayerScreen, self.provider, dummy_singer, dummy_album, queue, index)
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading stream URL.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to play song:\n%s" % err, MessageBox.TYPE_ERROR)


class MyhitsSingerScreen(MyhitsBrowserBase):
    def __init__(self, session, provider):
        self.provider = provider
        MyhitsBrowserBase.__init__(self, session, "%s Browser - Singers" % provider.name, [], "Loading singers...")
        self.loadData()

    def loadData(self):
        try:
            singers = self.provider.get_singers()
            self.setItems(singers)
            self["status"].setText("%d singer(s)" % len(singers))
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading singers.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to load singers:\n%s" % err, MessageBox.TYPE_ERROR)

    def openItem(self, item):
        screen = PROVIDER_ALBUM_SCREENS.get(self.provider.name, MyhitsAlbumScreen)
        self.session.open(screen, self.provider, item)


class SongSelectionScreen(Screen):
    skin = """
    <screen name="SongSelectionScreen" position="center,center" size="1100,630" title="Select songs to download">
        <widget name="title" position="20,15" size="1060,40" font="Regular;30" />
        <widget name="status" position="20,60" size="1060,32" font="Regular;24" />
        <widget name="songlist" position="20,100" size="1060,430" scrollbarMode="showOnDemand" itemHeight="40" />
        <widget name="key_red" position="20,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="20,596" size="220,8" backgroundColor="#b71c1c" />
        <widget name="key_green" position="250,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="250,596" size="220,8" backgroundColor="#1b5e20" />
        <widget name="key_yellow" position="480,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="480,596" size="220,8" backgroundColor="#f9a825" />
    </screen>
    """

    def __init__(self, session, provider, singer, album, songs):
        if hasattr(self.__class__, 'skin'):
            self.skin = scale_skin(self.__class__.skin)
        Screen.__init__(self, session)
        self.provider = provider
        self.singer = singer
        self.album = album
        self.songs = songs
        self.selected_indices = set()
        self.on_icon = self._load_icon("lock_on.png")
        self.off_icon = self._load_icon("lock_off.png")
        self.use_multicontent = all([
            eListboxPythonMultiContent is not None,
            MultiContentEntryText is not None,
            MultiContentEntryPixmapAlphaTest is not None,
            self.on_icon is not None,
            self.off_icon is not None,
        ])

        self["title"] = Label("Album: %s" % album.get("name", ""))
        self["status"] = Label("Select songs (OK = toggle, Green = Download, Yellow = Toggle all)")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Download")
        self["key_yellow"] = Label("Toggle all")

        if self.use_multicontent:
            self["songlist"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
            try:
                if gFont is not None:
                    self["songlist"].l.setFont(0, gFont("Regular", scale_int(26)))
                    self["songlist"].l.setItemHeight(scale_int(40))
            except Exception:
                pass
        else:
            self["songlist"] = MenuList([])
            try:
                if gFont is not None:
                    self["songlist"].l.setFont(0, gFont("Regular", scale_int(26)))
                    self["songlist"].l.setItemHeight(scale_int(40))
            except Exception:
                pass

        self.updateSongList()

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "cancel": self.cancel,
                "red": self.cancel,
                "green": self.downloadSelected,
                "yellow": self.toggleAll,
                "ok": self.toggleCurrent,
                "up": self.moveUp,
                "down": self.moveDown,
            },
            -1,
        )

    def _load_icon(self, name):
        path = os.path.join(IMG_DIR, name)
        if not os.path.exists(path) or loadPNG is None:
            return None
        try:
            return loadPNG(path)
        except Exception:
            return None

    def _build_row(self, idx, song):
        checked = idx in self.selected_indices
        if not self.use_multicontent:
            checkbox = "[x]" if checked else "[ ]"
            return "%s %s" % (checkbox, song.get("name", "Unknown"))
        png = self.on_icon if checked else self.off_icon
        return [
            song,
            MultiContentEntryPixmapAlphaTest(pos=(scale_int(6), scale_int(2)), size=(scale_int(36), scale_int(36)), png=png),
            MultiContentEntryText(
                pos=(scale_int(54), 0),
                size=(scale_int(990), scale_int(40)),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP,
                text=song.get("name", "Unknown"),
                color=16777215,
                color_sel=16777215,
            ),
        ]

    def updateSongList(self):
        items = [self._build_row(idx, song) for idx, song in enumerate(self.songs)]
        self["songlist"].setList(items)
        self["status"].setText("Selected: %d / %d" % (len(self.selected_indices), len(self.songs)))

    def toggleCurrent(self):
        idx = self["songlist"].getSelectionIndex()
        if 0 <= idx < len(self.songs):
            if idx in self.selected_indices:
                self.selected_indices.remove(idx)
            else:
                self.selected_indices.add(idx)
            self.updateSongList()

    def toggleAll(self):
        if len(self.selected_indices) == len(self.songs):
            self.selected_indices.clear()
        else:
            self.selected_indices = set(range(len(self.songs)))
        self.updateSongList()

    def moveUp(self):
        self["songlist"].up()

    def moveDown(self):
        self["songlist"].down()

    def downloadSelected(self):
        if not self.selected_indices:
            self.session.open(MessageBox, "No songs selected.", MessageBox.TYPE_ERROR)
            return
        selected_songs = [self.songs[i] for i in sorted(self.selected_indices)]
        self.close(selected_songs)

    def cancel(self):
        self.close(None)




class DownloadManagerScreen(Screen):
    skin = """
    <screen name="DownloadManagerScreen" position="center,center" size="800,330" title="Downloading...">
        <widget name="label" position="20,20" size="760,40" font="Regular;26" halign="center" valign="center" />
        <widget name="current_song" position="20,70" size="760,30" font="Regular;22" halign="center" valign="center" />
        <widget name="song_count" position="20,105" size="760,26" font="Regular;22" halign="center" valign="center" />
        <widget name="bitrate_label" position="20,136" size="760,24" font="Regular;22" halign="center" valign="center" />
        <widget name="progress" position="20,170" size="760,26" backgroundColor="#00000000" foregroundColor="#0000ff00" />
        <widget name="progress_text" position="20,203" size="760,26" font="Regular;22" halign="center" valign="center" />
        <widget name="key_red" position="300,260" size="200,32" font="Regular;24" halign="center" valign="center" />
    </screen>
    """

    def __init__(self, session, provider, singer, album, songs_to_download):
        if hasattr(self.__class__, 'skin'):
            self.skin = scale_skin(self.__class__.skin)
        Screen.__init__(self, session)
        self.provider = provider
        self.singer = singer
        self.album = album
        self.songs = songs_to_download
        self.current_idx = 0
        self.cancelled = False
        self.total = len(songs_to_download)

        self._worker = None
        self._timer = None
        self._download_done = False
        self._download_error = ""
        self._current_total_bytes = 0
        self._current_downloaded_bytes = 0
        self._current_song_name = ""
        self._current_bitrate = None
        self._bitrate_thread = None

        self["label"] = Label("Preparing downloads...")
        self["current_song"] = Label("")
        self["song_count"] = Label("")
        self["bitrate_label"] = Label("Bitrate: -- kb/s")
        self["progress_text"] = Label("0%")
        self["key_red"] = Label("Cancel")
        if ProgressBar is not None:
            self["progress"] = ProgressBar()
            self["progress"].setRange((0, 1000))
            self["progress"].setValue(0)
        else:
            self["progress"] = Label("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "cancel": self.cancel,
                "red": self.cancel,
            },
            -1,
        )

        if eTimer is not None:
            self._timer = eTimer()
            try:
                self._timer.timeout.connect(self._pollDownload)
            except Exception:
                self._timer.callback.append(self._pollDownload)

        self.onFirstExecBegin.append(self.startDownloads)
        self.onClose.append(self._onClose)

    def _fmt_size(self, value):
        try:
            value = float(value)
        except Exception:
            value = 0.0
        for unit in ["B", "KB", "MB", "GB"]:
            if value < 1024.0 or unit == "GB":
                if unit == "B":
                    return "%d %s" % (int(value), unit)
                return "%.1f %s" % (value, unit)
            value /= 1024.0
        return "0 B"

    def _safe_filename_parts(self, txt):
        txt = re.sub(r'[\\/*?:"<>|\s]+', '_', txt)
        txt = re.sub(r'_+', '_', txt).strip('_')
        return txt.lower()

    def _probeBitrateWorker(self, stream_url):
        try:
            self._current_bitrate = getAudioBitrate(stream_url)
        except Exception:
            self._current_bitrate = None

    def _updateWidgets(self):
        current_num = min(self.current_idx + 1, self.total) if self.total else 0
        self["label"].setText("Downloading selected songs")
        self["song_count"].setText("%d / %d" % (current_num, self.total))
        self["current_song"].setText("Song: %s" % (self._current_song_name or ""))
        if self._current_bitrate and self._current_bitrate > 0:
            self["bitrate_label"].setText("Bitrate: %d kb/s" % int(self._current_bitrate))
        else:
            self["bitrate_label"].setText("Bitrate: probing...")
        pct = 0
        if self._current_total_bytes > 0:
            try:
                pct = int((float(self._current_downloaded_bytes) / float(self._current_total_bytes)) * 1000.0)
            except Exception:
                pct = 0
        pct = max(0, min(1000, pct))
        if ProgressBar is not None:
            try:
                self["progress"].setValue(pct)
            except Exception:
                pass
        percent_text = "%.1f%%" % (pct / 10.0)
        if self._current_total_bytes > 0:
            size_text = "%s / %s" % (
                self._fmt_size(self._current_downloaded_bytes),
                self._fmt_size(self._current_total_bytes),
            )
            self["progress_text"].setText("%s   %s" % (percent_text, size_text))
        else:
            self["progress_text"].setText("%s   %s" % (percent_text, self._fmt_size(self._current_downloaded_bytes)))

    def startDownloads(self):
        if not self.songs:
            self.session.open(MessageBox, "No songs selected.", MessageBox.TYPE_ERROR)
            self.close()
            return
        self._startCurrentDownload()

    def _startCurrentDownload(self):
        if self.cancelled or self.current_idx >= self.total:
            self.finish()
            return
        song = self.songs[self.current_idx]
        self._current_song_name = song.get("name", "")
        self._current_total_bytes = 0
        self._current_downloaded_bytes = 0
        self._download_done = False
        self._download_error = ""
        self._current_bitrate = None
        self._updateWidgets()

        try:
            stream_url = self.provider.get_song_stream_url(song["url"])
        except Exception:
            stream_url = ""
        if stream_url:
            try:
                self._bitrate_thread = threading.Thread(target=self._probeBitrateWorker, args=(stream_url,), daemon=True)
                self._bitrate_thread.start()
            except Exception:
                self._bitrate_thread = None

        self._worker = threading.Thread(target=self._download_worker, args=(song,), daemon=True)
        self._worker.start()
        if self._timer is not None:
            try:
                self._timer.start(300)
            except Exception:
                self._timer.start(300, False)

    def _download_worker(self, song):
        try:
            stream_url = self.provider.get_song_stream_url(song["url"])
            if not stream_url:
                raise Exception("No stream URL")

            storage_root = ensure_storage_dirs()
            if not storage_root or not os.path.exists(storage_root):
                raise Exception("Storage path not set or invalid")

            singer_name = self._safe_filename_parts(clean_text(self.singer.get("name", "unknown")))
            album_name = self._safe_filename_parts(clean_text(self.album.get("name", "unknown")))
            song_name = self._safe_filename_parts(clean_text(song.get("name", "unknown")))
            filename = "%s_%s_%s.mp3" % (singer_name, album_name, song_name)
            if len(filename) > 200:
                base, ext = os.path.splitext(filename)
                filename = base[:196] + ext
            filepath = os.path.join(storage_root, filename)

            req = Request(stream_url, headers={"User-Agent": USER_AGENT})
            context = ssl.create_default_context()
            with urlopen(req, timeout=SOCKET_TIMEOUT, context=context) as response:
                try:
                    self._current_total_bytes = int(response.headers.get("Content-Length", "0") or "0")
                except Exception:
                    self._current_total_bytes = 0

                with open(filepath, "wb") as f:
                    while not self.cancelled:
                        chunk = response.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)
                        self._current_downloaded_bytes += len(chunk)

            if self.cancelled:
                try:
                    if os.path.exists(filepath):
                        os.remove(filepath)
                except Exception:
                    pass
            self._download_done = True
        except Exception as e:
            self._download_error = str(e)
            self._download_done = True

    def _pollDownload(self):
        self._updateWidgets()
        if not self._download_done:
            return

        try:
            if self._timer is not None:
                self._timer.stop()
        except Exception:
            pass

        if self.cancelled:
            self.finish()
            return

        song = self.songs[self.current_idx]
        if self._download_error:
            self.current_idx += 1
            self.session.openWithCallback(
                self._afterMessage,
                MessageBox,
                "Failed to download %s:\n%s" % (song.get("name", ""), self._download_error),
                MessageBox.TYPE_ERROR,
            )
        else:
            self.current_idx += 1
            self.session.openWithCallback(
                self._afterMessage,
                MessageBox,
                "Downloaded: %s" % song.get("name", ""),
                MessageBox.TYPE_INFO,
                timeout=1,
            )

    def _afterMessage(self, answer=None):
        if self.cancelled or self.current_idx >= self.total:
            self.finish()
        else:
            self._startCurrentDownload()

    def cancel(self):
        self.cancelled = True
        self["label"].setText("Cancelling...")
        self["key_red"].setText("Closing")
        if self._download_done:
            self.close()

    def finish(self):
        try:
            if self._timer is not None:
                self._timer.stop()
        except Exception:
            pass
        if self.cancelled:
            self.session.open(MessageBox, "Download cancelled.", MessageBox.TYPE_INFO)
        else:
            self["song_count"].setText("%d / %d" % (self.total, self.total))
            if ProgressBar is not None:
                try:
                    self["progress"].setValue(1000)
                except Exception:
                    pass
            self["progress_text"].setText("100.0%")
            self.session.open(MessageBox, "All selected songs downloaded successfully.", MessageBox.TYPE_INFO)
        self.close()

    def _onClose(self):
        try:
            if self._timer is not None:
                self._timer.stop()
        except Exception:
            pass


class MyhitsAlbumScreen(MyhitsBrowserBase):
    skin = """
    <screen name="MyhitsAlbumScreen" position="center,center" size="1100,630" title="MyHits Browser">
        <widget name="title" position="20,15" size="1060,40" font="Regular;30" />
        <widget name="status" position="20,60" size="740,32" font="Regular;24" />
        <widget name="list" position="20,100" size="740,430" scrollbarMode="showOnDemand" itemHeight="40" font="Regular;30" valign="center" />
        <widget name="singer_art" position="850,110" size="150,150" zPosition="2" alphatest="blend" scale="1" cornerRadius="50" />
        <widget name="album_art" position="850,290" size="150,150" zPosition="2" alphatest="blend" scale="1" cornerRadius="20" />
        <widget name="singer_label" position="820,265" size="210,28" font="Regular;22" halign="center" valign="center" />
        <widget name="album_label" position="820,445" size="210,28" font="Regular;22" halign="center" valign="center" />
        <widget name="key_red" position="20,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="20,596" size="220,8" backgroundColor="#b71c1c" />
        <widget name="key_green" position="250,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="250,596" size="220,8" backgroundColor="#1b5e20" />
        <widget name="key_yellow" position="480,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="480,596" size="220,8" backgroundColor="#f9a825" />
        <widget name="key_blue" position="710,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="710,596" size="220,8" backgroundColor="#0d47a1" />
        <widget name="key_menu" position="940,560" size="140,32" font="Regular;24" halign="center" valign="center" />
    </screen>
    """

    def __init__(self, session, provider, singer):
        self.provider = provider
        self.singer = singer
        MyhitsBrowserBase.__init__(self, session, "%s Browser - Albums" % provider.name, [], "Loading albums...")
        self.enableMenu(True, "Menu")
        self["singer_label"] = Label(clean_text(self.singer.get("name", "Singer")))
        self["album_label"] = Label("")
        self["singer_art"] = Pixmap() if Pixmap is not None else Label("")
        self["album_art"] = Pixmap() if Pixmap is not None else Label("")
        clear_pixmap(self["singer_art"] if Pixmap is not None else None)
        clear_pixmap(self["album_art"] if Pixmap is not None else None)
        self._last_album_url = None
        self._art_refresh_timer = None
        try:
            self["list"].onSelectionChanged.append(self.onSelectionChanged)
        except Exception:
            pass
        if eTimer is not None:
            self._art_refresh_timer = eTimer()
            try:
                self._art_refresh_timer.timeout.connect(self.refreshArts)
            except Exception:
                self._art_refresh_timer.callback.append(self.refreshArts)
        self.onShown.append(self.deferRefreshArts)
        self.loadData()
        self.updateSingerArt()

    def updateSingerArt(self):
        if Pixmap is None:
            return
        try:
            image_url = self.provider.get_singer_image(self.singer.get("url", ""))
            image_file = get_local_singer_image_file(image_url)
            if not set_pixmap_from_file(self["singer_art"], image_file):
                clear_pixmap(self["singer_art"])
        except Exception:
            clear_pixmap(self["singer_art"])

    def updateAlbumArt(self):
        item = self.getCurrentItem()
        self["album_label"].setText(clean_text(item.get("name", "")) if item else "")
        if Pixmap is None:
            return
        album_url = item.get("url", "") if item else ""
        if not album_url or album_url == self._last_album_url:
            return
        self._last_album_url = album_url
        try:
            image_url = self.provider.get_album_image(album_url)
            image_file = get_local_cover_art_file(image_url)
            if not set_pixmap_from_file(self["album_art"], image_file):
                clear_pixmap(self["album_art"])
        except Exception:
            clear_pixmap(self["album_art"])

    def onSelectionChanged(self):
        self.updateAlbumArt()

    def deferRefreshArts(self):
        try:
            self.onShown.remove(self.deferRefreshArts)
        except Exception:
            pass
        if self._art_refresh_timer is not None:
            try:
                self._art_refresh_timer.start(150, True)
            except Exception:
                self._art_refresh_timer.start(150, False)
        else:
            self.refreshArts()

    def refreshArts(self):
        self._last_album_url = None
        self.updateSingerArt()
        self.updateAlbumArt()

    def loadData(self):
        try:
            albums = self.provider.get_albums(self.singer["url"])
            self.setItems(albums)
            try:
                self["list"].moveToIndex(0)
            except Exception:
                pass
            self["status"].setText("%d album(s)" % len(albums))
            self.updateAlbumArt()
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading albums.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to load albums:\n%s" % err, MessageBox.TYPE_ERROR)

    def keyMenu(self):
        item = self.getCurrentItem()
        if not item or ChoiceBox is None:
            return
        menu_items = [
            (("Send album songs to singer bouquet", "fav_album")),
            (("Download album songs", "download_album"))
        ]
        self.session.openWithCallback(self.menuCallback, ChoiceBox, title="Album actions", list=menu_items)

    def menuCallback(self, answer):
        if not answer:
            return
        choice = answer[1] if isinstance(answer, (list, tuple)) and len(answer) > 1 else answer
        action = choice[1] if isinstance(choice, (list, tuple)) else choice
        if action == "fav_album":
            self.sendAlbumToSingerBouquet()
        elif action == "download_album":
            self.downloadAlbumSongs()

    def sendAlbumToSingerBouquet(self):
        album = self.getCurrentItem()
        if not album:
            return
        try:
            songs = self.provider.get_songs(album["url"])
            added = 0
            failed = 0
            for song in songs:
                try:
                    stream_url = self.provider.get_song_stream_url(song["url"])
                    ok, _msg = add_service_to_singer_bouquet(self.singer.get("name", PLUGIN_NAME), "%s - %s" % (self.singer.get("name", ""), song.get("name", "Song")), stream_url)
                    if ok:
                        added += 1
                    else:
                        failed += 1
                except Exception:
                    failed += 1
            self.session.open(MessageBox, "Singer bouquet processed. Added: %d, Failed: %d" % (added, failed), MessageBox.TYPE_INFO)
        except Exception as err:
            self.session.open(MessageBox, "Failed to send album:\n%s" % err, MessageBox.TYPE_ERROR)

    def downloadAlbumSongs(self):
        album = self.getCurrentItem()
        if not album:
            return
        try:
            songs = self.provider.get_songs(album["url"])
            if not songs:
                self.session.open(MessageBox, "No songs found in this album.", MessageBox.TYPE_ERROR)
                return
            self.session.openWithCallback(self.downloadSelectedSongs, SongSelectionScreen, self.provider, self.singer, album, songs)
        except Exception as err:
            self.session.open(MessageBox, "Failed to load songs:\n%s" % err, MessageBox.TYPE_ERROR)

    def downloadSelectedSongs(self, selected_songs):
        if not selected_songs:
            return
        self.session.open(DownloadManagerScreen, self.provider, self.singer, self.getCurrentItem(), selected_songs)

    def openItem(self, item):
        screen = PROVIDER_SONG_SCREENS.get(self.provider.name, MyhitsSongScreen)
        self.session.open(screen, self.provider, self.singer, item)


class MyhitsSongScreen(MyhitsBrowserBase):
    def __init__(self, session, provider, singer, album):
        self.provider = provider
        self.singer = singer
        self.album = album
        MyhitsBrowserBase.__init__(self, session, "%s Browser - Songs" % provider.name, [], "Loading songs...")
        self["key_green"].setText("Play")
        self.enableMenu(True, "Menu")
        self.loadData()

    def loadData(self):
        try:
            songs = self.provider.get_songs(self.album["url"])
            self.setItems(songs)
            self["status"].setText("%d song(s)" % len(songs))
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading songs.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to load songs:\n%s" % err, MessageBox.TYPE_ERROR)

    def keyMenu(self):
        item = self.getCurrentItem()
        if not item or ChoiceBox is None:
            return
        menu_items = [
            (("Send song to singer bouquet", "fav_song")),
            (("Download song", "download"))
        ]
        self.session.openWithCallback(self.menuCallback, ChoiceBox, title="Song actions", list=menu_items)

    def menuCallback(self, answer):
        if not answer:
            return
        choice = answer[1] if isinstance(answer, (list, tuple)) and len(answer) > 1 else answer
        action = choice[1] if isinstance(choice, (list, tuple)) else choice
        if action == "fav_song":
            self.sendSongToSingerBouquet()
        elif action == "download":
            self.downloadCurrentSong()

    def sendSongToSingerBouquet(self):
        item = self.getCurrentItem()
        if not item:
            return
        try:
            stream_url = self.provider.get_song_stream_url(item["url"])
            ok, msg = add_service_to_singer_bouquet(self.singer.get("name", PLUGIN_NAME), "%s - %s" % (self.singer.get("name", ""), item.get("name", "Song")), stream_url)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to send song:\n%s" % err, MessageBox.TYPE_ERROR)

    def downloadCurrentSong(self):
        item = self.getCurrentItem()
        if not item:
            return
        try:
            stream_url = self.provider.get_song_stream_url(item["url"])
            if not stream_url:
                self.session.open(MessageBox, "No audio stream URL found for this song.", MessageBox.TYPE_ERROR)
                return
            storage_root = ensure_storage_dirs()
            if not storage_root or not os.path.exists(storage_root):
                self.session.open(MessageBox, "Storage path does not exist. Please set a valid path in settings.", MessageBox.TYPE_ERROR)
                return
            def safe_underscore(txt):
                txt = re.sub(r'[\\/*?:"<>|\s]+', '_', txt)
                txt = re.sub(r'_+', '_', txt).strip('_')
                return txt.lower()
            singer_name = safe_underscore(clean_text(self.singer.get("name", "unknown")))
            album_name = safe_underscore(clean_text(self.album.get("name", "unknown")))
            song_name = safe_underscore(clean_text(item.get("name", "unknown")))
            filename = f"{singer_name}_{album_name}_{song_name}.mp3"
            if len(filename) > 200:
                base, ext = os.path.splitext(filename)
                filename = base[:196] + ext
            filepath = os.path.join(storage_root, filename)
            req = Request(stream_url, headers={"User-Agent": USER_AGENT})
            context = ssl.create_default_context()
            with urlopen(req, timeout=SOCKET_TIMEOUT, context=context) as response:
                data = response.read()
            with open(filepath, "wb") as f:
                f.write(data)
            self.session.open(MessageBox, "Download completed:\n%s" % filepath, MessageBox.TYPE_INFO)
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while downloading song.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to download song:\n%s" % err, MessageBox.TYPE_ERROR)

    def openItem(self, item):
        try:
            current = self.getCurrentItem()
            index = self.filtered_items.index(current) if current in self.filtered_items else 0
            queue = []
            for song in self.filtered_items:
                queue.append({"name": song.get("name", "Song"), "url": song.get("url", "")})
            self.session.open(MyhitsPlayerScreen, self.provider, self.singer, self.album, queue, index)
        except socket.timeout:
            self.session.open(MessageBox, "Timeout while loading stream URL.", MessageBox.TYPE_ERROR)
        except Exception as err:
            self.session.open(MessageBox, "Failed to play song:\n%s" % err, MessageBox.TYPE_ERROR)


class AlbumatySingerScreen(MyhitsSingerScreen):
    pass


class AlbumatyAlbumScreen(MyhitsAlbumScreen):
    pass


class AlbumatySongScreen(MyhitsSongScreen):
    pass


PROVIDER_SINGER_SCREENS = {"Albumaty": AlbumatyMenuScreen}
PROVIDER_ALBUM_SCREENS = {"Albumaty": AlbumatyAlbumScreen}
PROVIDER_SONG_SCREENS = {"Albumaty": AlbumatySongScreen}


# Folder selection screen
if FileList is not None and StaticText is not None:
    class FolderSelect(Screen):
        skin = """
            <screen position="center,center" size="1100,630" title="Select Folder" flags="wfNoBorder">
                <eLabel name="" position="0,0" size="1100,630" zPosition="-99" />
                <widget name="title" position="20,15" size="1060,40" font="Regular;30" halign="left" valign="center" transparent="1" foregroundColor="white" />
                <widget name="filelist" position="20,70" size="1060,430" scrollbarMode="showOnDemand" itemHeight="40" font="Regular;26" />
                <widget name="folderinfo" position="20,510" size="1060,40" font="Regular;24" halign="left" valign="center" transparent="1" foregroundColor="white" />
                <widget source="key_red" render="Label" position="20,560" size="220,32" backgroundColor="#b71c1c" font="Regular;24" valign="center" halign="center" />
                <widget source="key_green" render="Label" position="250,560" size="220,32" backgroundColor="#1b5e20" font="Regular;24" valign="center" halign="center" />
                <eLabel position="20,550" size="1060,2" backgroundColor="darkgrey" />
            </screen>
        """
        
        def __init__(self, session, current_dir):
            if hasattr(self.__class__, 'skin'):
                self.skin = scale_skin(self.__class__.skin)
            Screen.__init__(self, session)
            self.session = session
            self["title"] = Label("Select Folder")
            self["folderinfo"] = Label()
            self["key_red"] = StaticText(_("Cancel"))
            self["key_green"] = StaticText(_("Select"))
            if not current_dir or not os.path.exists(current_dir):
                current_dir = "/"
            self["filelist"] = FileList(
                current_dir,
                showDirectories=True,
                showFiles=False,
                showMountpoints=True,
                useServiceRef=False
            )
            self["actions"] = ActionMap(["SetupActions", "ColorActions"],
            {
                "cancel": self.cancel,
                "red": self.cancel,
                "green": self.select,
                "ok": self.ok,
            }, -2)
            self.updateFolderInfo()
        
        def updateFolderInfo(self):
            current_dir = self["filelist"].getCurrentDirectory()
            self["folderinfo"].setText(f"Current Folder: {current_dir}")
        
        def ok(self):
            current = self["filelist"].getCurrent()
            if current and self["filelist"].canDescent():
                self["filelist"].descent()
                self.updateFolderInfo()
        
        def select(self):
            current_dir = self["filelist"].getCurrentDirectory()
            if not current_dir.endswith('/'):
                current_dir += '/'
            self.close(current_dir)
        
        def cancel(self):
            self.close(None)
else:
    class FolderSelect(Screen):
        def __init__(self, session, current_dir):
            Screen.__init__(self, session)
            self.session = session
            self.current_dir = current_dir
        def select(self):
            self.close(None)
        def cancel(self):
            self.close(None)


class MyhitsSettingsScreen(Screen, ConfigListScreen):
    skin = """
    <screen name="MyhitsSettingsScreen" position="center,center" size="1100,630" title="MyHits Browser Settings">
        <widget name="config" position="20,20" size="1060,520" scrollbarMode="showOnDemand" itemHeight="50" />
        <widget name="key_red" position="20,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="20,596" size="220,8" backgroundColor="#b71c1c" />
        <widget name="key_green" position="250,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="250,596" size="220,8" backgroundColor="#1b5e20" />
        <widget name="key_yellow" position="480,560" size="220,32" font="Regular;24" halign="center" valign="center" transparent="1" />
        <widget name="key_yellow_bg" position="480,596" size="220,8" backgroundColor="#f9a825" />
        <widget name="key_blue" position="710,560" size="220,32" font="Regular;24" halign="center" valign="center" />
        <eLabel name="" position="710,596" size="220,8" backgroundColor="#0d47a1" />
    </screen>
    """

    def __init__(self, session):
        if hasattr(self.__class__, 'skin'):
            self.skin = scale_skin(self.__class__.skin)
        Screen.__init__(self, session)
        try:
            self.setTitle("%s v%s - Settings" % (APP_BROWSER_TITLE, PLUGIN_VERSION))
        except Exception:
            pass
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("")
        self["key_yellow_bg"] = Label("")
        self["key_blue"] = Label("Clear Cache")
        self.path_entry = getConfigListEntry("Storage path", config.plugins.myhits.storage_path)
        entries = [
            getConfigListEntry("Player type", config.plugins.myhits.player),
            getConfigListEntry("Cache TTL", config.plugins.myhits.cache_ttl),
            self.path_entry,
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "save": self.keySave,
                "green": self.keySave,
                "ok": self.keyOK,
                "yellow": self.keyBrowse,
                "blue": self.keyClearCache,
            },
            -1,
        )
        
        if hasattr(self["config"], "onSelectionChanged"):
            self["config"].onSelectionChanged.append(self.updateButtons)
        self.onLayoutFinish.append(self.updateButtons)

    def updateButtons(self):
        if self.currentConfig() == self.path_entry:
            self["key_yellow"].setText("Browse")
            self["key_yellow_bg"].show()
        else:
            self["key_yellow"].setText("")
            self["key_yellow_bg"].hide()

    def currentConfig(self):
        try:
            return self["config"].getCurrent()
        except Exception:
            return None

    def keyOK(self):
        current = self.currentConfig()
        if current == self.path_entry:
            self.keyBrowse()
        else:
            ConfigListScreen.keyRight(self)

    def keyBrowse(self):
        current = self.currentConfig()
        if current != self.path_entry:
            return
        start_dir = config.plugins.myhits.storage_path.value or "/tmp/MyHits"
        self.session.openWithCallback(self.pathSelected, FolderSelect, start_dir)

    def pathSelected(self, path=None):
        if not path:
            return
        config.plugins.myhits.storage_path.value = path
        ensure_storage_dirs()
        try:
            self["config"].invalidate(self.path_entry)
        except Exception:
            pass

    def keySave(self):
        for item in self["config"].list:
            item[1].save()
        self.close(True)

    def keyCancel(self):
        for item in self["config"].list:
            item[1].cancel()
        self.close(False)

    def keyClearCache(self):
        clear_cache()
        self.session.open(MessageBox, "Cache cleared.", MessageBox.TYPE_INFO)


def main(session, **kwargs):
    session.open(MyhitsMainScreen)


def menu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(PLUGIN_NAME, main, "myhits_browser", 50)]
    return []


def Plugins(**kwargs):
    return [
        PluginDescriptor(name=PLUGIN_NAME, description="Browse online music providers", where=PluginDescriptor.WHERE_PLUGINMENU, icon=PLUGIN_LOGO, fnc=main),
        PluginDescriptor(name=PLUGIN_NAME, description="Browse online music providers", where=PluginDescriptor.WHERE_MENU, fnc=menu),
    ]